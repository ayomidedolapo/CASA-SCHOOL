import {
  createHash,
} from "node:crypto";
import {
  readFileSync,
} from "node:fs";

function source(
  path: string,
) {
  return readFileSync(
    path,
    "utf8",
  );
}

function sha256(
  path: string,
) {
  return createHash(
    "sha256",
  )
    .update(
      readFileSync(
        path,
      ),
    )
    .digest(
      "hex",
    );
}

function assert(
  condition: unknown,
  message: string,
): asserts condition {
  if (!condition) {
    throw new Error(
      message,
    );
  }
}

function expectMarkers(
  path: string,
  markers: string[],
) {
  const text =
    source(path);

  for (
    const marker of
    markers
  ) {
    assert(
      text.includes(
        marker,
      ),
      `${path} missing marker: ${marker}`,
    );
  }

  return text;
}

const globals =
  expectMarkers(
    "src/app/globals.css",
    [
      "--casa-paper: #f2f2ef",
      "--casa-ink: #0b0b0a",
      ".casa-kicker",
      ".casa-display-compact",
      ".casa-button",
      ".casa-field",
      ":focus-visible",
      "prefers-reduced-motion",
    ],
  );

assert(
  !globals.includes(
    "prefers-color-scheme: dark",
  ),
  "CASA frontend must not silently switch to a generic dark theme.",
);

const home =
  expectMarkers(
    "src/app/page.tsx",
    [
      "One school.",
      "One source of truth.",
      "School workspace",
      "Scanner terminal",
      "Account security",
    ],
  );

for (
  const stale of [
    "next.svg",
    "vercel.svg",
    "Create Next App",
    "Deploy Now",
  ]
) {
  assert(
    !home.includes(
      stale,
    ),
    `Default Next.js starter content remains: ${stale}`,
  );
}

const login =
  expectMarkers(
    "src/app/login/page.tsx",
    [
      "Enter the school",
      "operating system.",
      "Secure access",
    ],
  );

const loginForm =
  expectMarkers(
    "src/app/login/login-form.tsx",
    [
      "casa-field",
      "casa-button",
      "Signing in...",
    ],
  );

assert(
  !login.includes(
    "rounded-3xl",
  ) &&
  !loginForm.includes(
    "rounded-xl",
  ),
  "Login must use the square CASA visual system.",
);

const passkeyPage =
  expectMarkers(
    "src/app/security/passkeys/page.tsx",
    [
      "CASA / Security",
      "Your device becomes part of the approval.",
      "Security model",
    ],
  );

const passkeyManager =
  expectMarkers(
    "src/app/security/passkeys/passkey-manager.tsx",
    [
      "casa-status",
      "casa-button",
      "Windows Hello / CASA device",
    ],
  );

assert(
  !passkeyPage.includes(
    "style={{",
  ) &&
  !passkeyManager.includes(
    "style={{",
  ),
  "Passkey surfaces must not retain generic inline-card styling.",
);

const registry =
  expectMarkers(
    "src/app/schools/[slug]/registry/registry-client.tsx",
    [
      "async function updateStudent",
      "Save student changes",
      "Face / identity",
      "Register new student",
      "Create guardian",
      "School Registry.",
      "roles.join(\" · \")",
    ],
  );

assert(
  !registry.includes(
    "rounded-2xl",
  ) &&
  !registry.includes(
    "rounded-xl",
  ) &&
  !registry.includes(
    "bg-slate-50",
  ),
  "Registry still contains the old rounded/slate SaaS shell.",
);

const cards =
  expectMarkers(
    "src/app/schools/[slug]/registry/student-cards.tsx",
    [
      "Card production & lifecycle",
      "Card action reason",
      "Reissue with Passkey",
      "View finished card",
    ],
  );

assert(
  !cards.includes(
    "window.prompt(",
  ),
  "Card lifecycle still uses browser prompt dialogs.",
);

expectMarkers(
    "src/app/internal/onboarding/onboarding-client.tsx",
    [
      "Next incomplete →",
      "Register student before capture day",
      "Create & link guardian",
      "Assign class",
      "/academic-options",
      "Save details",
      "Release & next incomplete →",
      "card_production_need",
    ],
  );

const internalAcademic =
  expectMarkers(
    "src/app/api/internal/onboarding/schools/[schoolId]/academic-options/route.ts",
    [
      "requireCasaInternalSchoolAccess",
      "academicSessions",
      "classArms",
      "classLevels",
      "casaInternalNoStoreHeaders",
    ],
  );

assert(
  internalAcademic.includes(
    "export async function GET",
  ),
  "Internal academic options must remain read-only.",
);

for (
  const forbidden of [
    "export async function POST",
    "export async function PATCH",
    "export async function DELETE",
  ]
) {
  assert(
    !internalAcademic.includes(
      forbidden,
    ),
    "Internal academic-options route unexpectedly became mutating.",
  );
}

const attendanceCss =
  expectMarkers(
    "src/app/schools/[slug]/attendance/attendance.module.css",
    [
      "--paper: #f2f2ef",
      "--ink: #0b0b0a",
      "focus-visible",
    ],
  );

const technicianCss =
  expectMarkers(
    "src/app/schools/[slug]/technician/technician.module.css",
    [
      "--paper: #f2f2ef",
      "--ink: #0b0b0a",
      "focus-visible",
    ],
  );

const scannerCss =
  expectMarkers(
    "src/app/scanner/scanner.module.css",
    [
      "--paper: #f2f2ef",
      "--ink: #0b0b0a",
      "focus-visible",
    ],
  );

void attendanceCss;
void technicianCss;
void scannerCss;

const technician =
  source(
    "src/app/schools/[slug]/technician/technician-client.tsx",
  );

assert(
  !technician.includes(
    "separate next backend phase",
  ),
  "Technician UI still describes the already-built card-production engine as future work.",
);

const scannerClientSha =
  sha256(
    "src/app/scanner/scanner-client.tsx",
  );

assert(
  scannerClientSha ===
    "567724cd99f31d44951a5dbc60e4317cb31ce12eaee63577d05678b7e4c4da9d",
  "Scanner client trust-path source changed during frontend closure.",
);

const encodingTargets = [
  "src/app/page.tsx",
  "src/app/login/page.tsx",
  "src/app/login/login-form.tsx",
  "src/app/security/passkeys/page.tsx",
  "src/app/security/passkeys/passkey-manager.tsx",
  "src/app/schools/[slug]/registry/registry-client.tsx",
  "src/app/schools/[slug]/registry/student-cards.tsx",
  "src/app/internal/onboarding/onboarding-client.tsx",
  "src/app/schools/[slug]/attendance/attendance-client.tsx",
  "src/app/schools/[slug]/technician/technician-client.tsx",
];

const mojibakeMarkers = [
  "Ã",
  "Â",
  "â€¦",
  "Ãƒ",
  "Ã‚",
];

for (
  const path of
  encodingTargets
) {
  const text =
    source(path);

  for (
    const marker of
    mojibakeMarkers
  ) {
    assert(
      !text.includes(
        marker,
      ),
      `${path} still contains encoding corruption marker ${marker}`,
    );
  }
}

console.log(
  "CASA School comprehensive frontend closure self-test passed.",
);
