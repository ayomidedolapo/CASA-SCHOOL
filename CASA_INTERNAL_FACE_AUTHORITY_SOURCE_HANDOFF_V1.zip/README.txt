CASA School - Internal Face Authority Exact Source Handoff V1

Purpose:
- Provide the exact post-V1R4 source dependency closure needed to implement real CASA-internal face-capture authority/API unification safely.
- Avoid inventing auth, Passkey, DB/schema, liveness, or internal-role contracts from the earlier frontend-only handoff.

Safety:
- Source mutation: NO
- Database mutation/query: NO
- AWS mutation/query: NO
- Scanner attempt mutation: NO
- Migration mutation: NO
- Staging/Production mutation: NO
- Scanner client is included for context only and remains pinned to 567724cd99f31d44951a5dbc60e4317cb31ce12eaee63577d05678b7e4c4da9d.
- Pending Scanner Attempt 2 remains frozen. No QR scan is required or performed.

Scope includes:
- server auth/session/Passkey authority;
- internal CASA authorization/onboarding authority;
- DB/schema dependency closure;
- biometric/AWS liveness domain;
- school biometric/liveness routes;
- internal onboarding routes/UI;
- Passkey client/API routes;
- terminal biometric routes for shared-contract regression context;
- relevant tests and architecture notes.