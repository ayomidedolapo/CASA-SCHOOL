import Link from "next/link";

import { PasskeyManager } from "./passkey-manager";

export default function PasskeySecurityPage() {
  return (
    <main className="casa-shell">
      <div className="casa-container min-h-screen border-x border-black">
        <header className="grid gap-8 border-b border-black p-6 sm:p-10 lg:grid-cols-[1fr_auto] lg:items-end lg:p-12">
          <div>
            <p className="casa-kicker">
              CASA / Security
            </p>
            <h1 className="casa-display-compact mt-4">
              Passkeys.
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-6 text-black/55">
              Register device-backed credentials for sensitive CASA actions.
              Passkeys are separate from ordinary sign-in and are requested
              again when a protected operation needs fresh authorization.
            </p>
          </div>

          <Link
            className="casa-button-secondary w-fit"
            href="/"
          >
            Back to CASA
          </Link>
        </header>

        <div className="grid gap-0 lg:grid-cols-[0.72fr_1.28fr]">
          <aside className="border-b border-black p-6 sm:p-10 lg:border-b-0 lg:border-r lg:p-12">
            <p className="casa-kicker casa-muted">
              Security model
            </p>
            <h2 className="casa-heading mt-4">
              Your device becomes part of the approval.
            </h2>

            <div className="mt-8 border-t border-black">
              {[
                [
                  "01",
                  "Register",
                  "Create a Passkey with Windows Hello or another device authenticator.",
                ],
                [
                  "02",
                  "Step up",
                  "CASA requests a fresh Passkey authorization for protected actions.",
                ],
                [
                  "03",
                  "Audit",
                  "Sensitive operations remain tied to the authenticated actor and school scope.",
                ],
              ].map(
                ([index, title, copy]) => (
                  <div
                    className="grid grid-cols-[42px_1fr] gap-3 border-b border-black/25 py-4"
                    key={index}
                  >
                    <span className="font-mono text-[10px]">
                      {index}
                    </span>
                    <span>
                      <strong className="block text-sm">
                        {title}
                      </strong>
                      <span className="mt-1 block text-xs leading-5 text-black/55">
                        {copy}
                      </span>
                    </span>
                  </div>
                ),
              )}
            </div>
          </aside>

          <section className="p-6 sm:p-10 lg:p-12">
            <PasskeyManager />
          </section>
        </div>
      </div>
    </main>
  );
}
