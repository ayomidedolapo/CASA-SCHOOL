"use client";

import {
  type FormEvent,
  useState,
} from "react";
import Link from "next/link";
import {
  useRouter,
} from "next/navigation";

type JsonBody = {
  message?: string;
  roles?: string[];
};

export default function PasswordChangeClient(
  {
    schoolSlug,
  }: {
    schoolSlug:
      string;
  },
) {
  const router =
    useRouter();

  const [
    currentPassword,
    setCurrentPassword,
  ] =
    useState("");

  const [
    newPassword,
    setNewPassword,
  ] =
    useState("");

  const [
    confirmPassword,
    setConfirmPassword,
  ] =
    useState("");

  const [
    error,
    setError,
  ] =
    useState("");

  const [
    success,
    setSuccess,
  ] =
    useState("");

  const [
    busy,
    setBusy,
  ] =
    useState(false);

  async function continueToWorkspace() {
    if (!schoolSlug) {
      router.push(
        "/",
      );
      return;
    }

    const response =
      await fetch(
        `/api/schools/${encodeURIComponent(
          schoolSlug,
        )}/access`,
        {
          cache:
            "no-store",
        },
      );

    const body =
      (await response
        .json()
        .catch(
          () =>
            ({}),
        )) as JsonBody;

    if (
      !response.ok ||
      !Array.isArray(
        body.roles,
      )
    ) {
      router.push(
        `/login?school=${encodeURIComponent(
          schoolSlug,
        )}`,
      );
      return;
    }

    if (
      body.roles.includes(
        "OWNER",
      ) ||
      body.roles.includes(
        "ADMIN",
      )
    ) {
      router.push(
        `/schools/${encodeURIComponent(
          schoolSlug,
        )}/registry`,
      );
    } else if (
      body.roles.includes(
        "SCHOOL_TECHNICIAN",
      )
    ) {
      router.push(
        `/schools/${encodeURIComponent(
          schoolSlug,
        )}/technician`,
      );
    } else {
      router.push(
        `/schools/${encodeURIComponent(
          schoolSlug,
        )}/my-class`,
      );
    }

    router.refresh();
  }

  async function submit(
    event:
      FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    setError(
      "",
    );
    setSuccess(
      "",
    );

    if (
      newPassword !==
      confirmPassword
    ) {
      setError(
        "The new passwords do not match.",
      );
      return;
    }

    setBusy(
      true,
    );

    try {
      const response =
        await fetch(
          "/api/auth/password/change",
          {
            method:
              "POST",
            headers: {
              "Content-Type":
                "application/json",
            },
            body:
              JSON.stringify({
                currentPassword,
                newPassword,
              }),
          },
        );

      const body =
        (await response
          .json()
          .catch(
            () =>
              ({}),
          )) as JsonBody;

      if (!response.ok) {
        throw new Error(
          body.message ??
            "Unable to change password.",
        );
      }

      setSuccess(
        "Password changed. This temporary credential is no longer valid.",
      );

      setCurrentPassword(
        "",
      );
      setNewPassword(
        "",
      );
      setConfirmPassword(
        "",
      );

      await continueToWorkspace();
    } catch (error) {
      setError(
        error instanceof Error
          ? error.message
          : "Unable to change password.",
      );
    } finally {
      setBusy(
        false,
      );
    }
  }

  return (
    <main className="casa-shell min-h-screen px-5 py-8 sm:px-8 lg:px-12">
      <div className="casa-container">
        <header className="flex items-end justify-between gap-6 border-b border-black pb-5">
          <div>
            <p className="casa-kicker text-black/45">
              CASA / Account security
            </p>
            <h1 className="mt-3 text-5xl font-semibold tracking-[-0.06em] sm:text-7xl">
              Change password.
            </h1>
          </div>

          <Link
            href="/security/passkeys"
            className="casa-button-secondary"
          >
            Passkeys
          </Link>
        </header>

        <div className="mt-10 grid gap-10 lg:grid-cols-[minmax(0,0.8fr)_minmax(320px,0.55fr)]">
          <section>
            <p className="max-w-2xl text-lg leading-8 text-black/55">
              Temporary staff passwords must be replaced before normal password access continues. Your Passkeys are managed separately.
            </p>
          </section>

          <form
            onSubmit={
              submit
            }
            className="border-t border-black pt-6"
          >
            <label className="casa-label">
              <span>
                Current password
              </span>
              <input
                type="password"
                autoComplete="current-password"
                required
                value={
                  currentPassword
                }
                onChange={(
                  event,
                ) =>
                  setCurrentPassword(
                    event
                      .target
                      .value,
                  )
                }
                className="casa-field"
              />
            </label>

            <label className="casa-label mt-5">
              <span>
                New password
              </span>
              <input
                type="password"
                autoComplete="new-password"
                minLength={
                  12
                }
                required
                value={
                  newPassword
                }
                onChange={(
                  event,
                ) =>
                  setNewPassword(
                    event
                      .target
                      .value,
                  )
                }
                className="casa-field"
              />
            </label>

            <label className="casa-label mt-5">
              <span>
                Confirm new password
              </span>
              <input
                type="password"
                autoComplete="new-password"
                minLength={
                  12
                }
                required
                value={
                  confirmPassword
                }
                onChange={(
                  event,
                ) =>
                  setConfirmPassword(
                    event
                      .target
                      .value,
                  )
                }
                className="casa-field"
              />
            </label>

            {error ? (
              <div
                className="casa-error mt-5"
                role="alert"
              >
                {error}
              </div>
            ) : null}

            {success ? (
              <div
                className="mt-5 border-l-2 border-[#176744] bg-[#e7f1eb] px-4 py-3 text-sm text-[#176744]"
                role="status"
              >
                {success}
              </div>
            ) : null}

            <button
              type="submit"
              disabled={
                busy
              }
              className="casa-button mt-6 w-full"
            >
              {busy
                ? "Updating..."
                : "Save new password →"}
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}
