import Link from "next/link";
import {
  redirect,
} from "next/navigation";

import {
  requireCasaInternalAccess,
} from "@/server/internal/authorization";

export default async function CasaTeamTechnicianPage() {
  try {
    await requireCasaInternalAccess();
  } catch (error) {
    if (
      error instanceof
        Error &&
      (
        error.name ===
          "AuthRequiredError" ||
        error.name ===
          "CasaInternalAuthRequiredError"
      )
    ) {
      redirect(
        "/login",
      );
    }

    throw error;
  }

  const operations = [
    {
      index:
        "01",
      title:
        "Student onboarding",
      description:
        "Search schools, complete identity records, link guardians, assign class/session and capture face.",
      href:
        "/internal/onboarding",
      action:
        "Open onboarding",
    },
    {
      index:
        "02",
      title:
        "Scanner rollout",
      description:
        "Open the dedicated Scanner PWA for installation and device QA. Terminal provisioning remains school-scoped and Passkey-protected.",
      href:
        "/scanner",
      action:
        "Open scanner",
    },
    {
      index:
        "03",
      title:
        "Account security",
      description:
        "Manage your own CASA Passkeys used for secure sign-in and sensitive field operations.",
      href:
        "/security/passkeys",
      action:
        "Manage Passkeys",
    },
  ];

  return (
    <main className="casa-shell min-h-screen px-5 py-7 sm:px-8 lg:px-12">
      <div className="casa-container">
        <header className="border-b border-black pb-7">
          <p className="casa-kicker text-black/45">
            CASA / Team Technician
          </p>
          <h1 className="mt-4 max-w-[9ch] text-6xl font-semibold tracking-[-0.065em] sm:text-8xl lg:text-9xl">
            Field operations.
          </h1>
          <p className="mt-6 max-w-2xl text-base leading-7 text-black/50">
            CASA Team Technicians operate here. This workspace is separate from each school’s School Technician workspace.
          </p>
        </header>

        <div className="mt-10 grid gap-px bg-black lg:grid-cols-3">
          {operations.map(
            (
              operation,
            ) => (
              <article
                key={
                  operation.index
                }
                className="flex min-h-80 flex-col bg-[var(--casa-paper)] p-6"
              >
                <p className="text-6xl font-semibold tracking-[-0.07em]">
                  {operation.index}
                </p>
                <div className="mt-auto pt-16">
                  <h2 className="text-2xl font-semibold tracking-[-0.035em]">
                    {operation.title}
                  </h2>
                  <p className="mt-3 text-sm leading-6 text-black/50">
                    {operation.description}
                  </p>
                  <Link
                    href={
                      operation.href
                    }
                    className="casa-button mt-6 inline-flex"
                  >
                    {operation.action} →
                  </Link>
                </div>
              </article>
            ),
          )}
        </div>

        <div className="mt-8 border-t border-black pt-5">
          <p className="font-mono text-[9px] uppercase tracking-[0.12em] text-black/45">
            School Technician workspace remains /schools/[slug]/technician · CASA Team authority remains internal.
          </p>
        </div>
      </div>
    </main>
  );
}
