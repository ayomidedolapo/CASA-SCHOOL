import {
  requireCasaInternalAccess,
} from "@/server/internal/authorization";

import InternalOnboardingClient from "./onboarding-client";

export default async function InternalOnboardingPage() {
  const access =
    await requireCasaInternalAccess();

  return (
    <InternalOnboardingClient
      actorName={
        access.session.fullName
      }
      role={
        access.membership.role
      }
    />
  );
}
