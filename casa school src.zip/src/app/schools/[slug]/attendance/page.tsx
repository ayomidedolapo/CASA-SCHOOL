import Link from "next/link";

import {
  requireSchoolRole,
} from "@/server/auth/authorization";

import AttendanceClient from "./attendance-client";

interface AttendancePageProps {
  params: Promise<{
    slug: string;
  }>;
}

export default async function AttendancePage(
  {
    params,
  }: AttendancePageProps,
) {
  const {
    slug,
  } =
    await params;

  const access =
    await requireSchoolRole(
      slug,
      [
        "OWNER",
        "ADMIN",
        "SCHOOL_TECHNICIAN",
      ],
    );

  const canManage =
    access.roles.some(
      (role) =>
        role ===
          "OWNER" ||
        role ===
          "ADMIN",
    );

  return (
    <>
      <div className="border-b border-black bg-[#f2f2ef] px-5 py-4 text-[#0b0b0a] sm:px-8">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-4">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.22em]">
              Attendance operations
            </p>
            <p className="mt-1 text-sm">
              {access.school.name}
            </p>
          </div>

          {canManage ? (
            <Link
              className="border border-black bg-black px-4 py-2 font-mono text-[10px] uppercase tracking-[0.16em] text-[#f2f2ef] transition hover:bg-[#f2f2ef] hover:text-black"
              href={`/schools/${encodeURIComponent(
                slug,
              )}/attendance/transport`}
            >
              Transport &amp; grace
            </Link>
          ) : (
            <Link
              className="border border-black px-4 py-2 font-mono text-[10px] uppercase tracking-[0.16em] transition hover:bg-black hover:text-[#f2f2ef]"
              href={`/schools/${encodeURIComponent(
                slug,
              )}/technician/attendance`}
            >
              Operator view
            </Link>
          )}
        </div>
      </div>

      <AttendanceClient
        slug={
          slug
        }
        schoolName={
          access.school.name
        }
        canManage={
          canManage
        }
      />
    </>
  );
}
