import Link from "next/link";

import {
  requireSchoolRole,
} from "@/server/auth/authorization";

import TransportClient from "./transport-client";

interface PageProps {
  params: Promise<{
    slug: string;
  }>;
}

export default async function AttendanceTransportPage({
  params,
}: PageProps) {
  const { slug } = await params;
  const access =
    await requireSchoolRole(
      slug,
      ["OWNER", "ADMIN"],
    );

  return (
    <main className="min-h-screen bg-[#f2f2ef] text-[#0b0b0a]">
      <header className="border-b border-black px-5 py-6 sm:px-8">
        <div className="mx-auto flex max-w-[1500px] items-start justify-between gap-5">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.22em]">
              Attendance / transport policy
            </p>
            <h1 className="mt-3 max-w-4xl text-4xl font-semibold tracking-[-0.05em] sm:text-6xl">
              Grace is policy, not guesswork.
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-6 text-black/65">
              Configure exact arrival grace by transport method and administratively assign each student&apos;s method with an effective date.
            </p>
          </div>

          <Link
            className="border border-black px-4 py-2 font-mono text-[10px] uppercase tracking-[0.16em] hover:bg-black hover:text-[#f2f2ef]"
            href={`/schools/${encodeURIComponent(
              slug,
            )}/attendance`}
          >
            Back
          </Link>
        </div>
      </header>

      <TransportClient
        slug={slug}
        schoolName={access.school.name}
        schoolTimezone={access.school.timezone}
      />
    </main>
  );
}
