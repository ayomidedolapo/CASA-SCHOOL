import Link from "next/link";

import {
  requireSchoolRole,
} from "@/server/auth/authorization";

import TechnicianAttendanceClient from "./technician-attendance-client";

interface PageProps {
  params: Promise<{
    slug: string;
  }>;
}

export default async function TechnicianAttendancePage({
  params,
}: PageProps) {
  const { slug } = await params;
  const access =
    await requireSchoolRole(
      slug,
      [
        "OWNER",
        "ADMIN",
        "SCHOOL_TECHNICIAN",
      ],
    );

  return (
    <main className="min-h-screen bg-[#f2f2ef] text-[#0b0b0a]">
      <header className="border-b border-black px-5 py-6 sm:px-8">
        <div className="mx-auto flex max-w-[1500px] items-start justify-between gap-5">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.22em]">
              Technician / attendance
            </p>
            <h1 className="mt-3 text-4xl font-semibold tracking-[-0.05em] sm:text-6xl">
              Today, clearly.
            </h1>
            <p className="mt-3 text-sm text-black/60">
              {access.school.name}
            </p>
          </div>

          <Link
            className="border border-black px-4 py-2 font-mono text-[10px] uppercase tracking-[0.16em] hover:bg-black hover:text-[#f2f2ef]"
            href={`/schools/${encodeURIComponent(
              slug,
            )}/technician`}
          >
            Back
          </Link>
        </div>
      </header>

      <TechnicianAttendanceClient
        slug={slug}
      />
    </main>
  );
}
