import Link from "next/link";

import {
  requireSchoolRole,
} from "@/server/auth/authorization";

import TechnicianClient from "./technician-client";

interface TechnicianPageProps {
  params: Promise<{
    slug: string;
  }>;
}

export default async function TechnicianPage(
  {
    params,
  }: TechnicianPageProps,
) {
  const {
    slug,
  } =
    await params;

  const access =
    await requireSchoolRole(
      slug,
      [
        "OWNER",
        "ADMIN",
        "SCHOOL_TECHNICIAN",
      ],
    );

  return (
    <>
      <div className="border-b border-black bg-[#f2f2ef] px-5 py-5 text-[#0b0b0a] sm:px-8">
        <div className="mx-auto grid max-w-[1500px] gap-5 md:grid-cols-[1fr_auto] md:items-end">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.22em]">
              School technician
            </p>
            <h1 className="mt-2 max-w-3xl text-3xl font-semibold tracking-[-0.04em] sm:text-5xl">
              Run the school day.
            </h1>
          </div>

          <Link
            className="w-fit border border-black bg-black px-5 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-[#f2f2ef] transition hover:bg-[#f2f2ef] hover:text-black"
            href={`/schools/${encodeURIComponent(
              slug,
            )}/technician/attendance`}
          >
            Attendance operations
          </Link>
        </div>
      </div>

      <TechnicianClient
        slug={
          slug
        }
        schoolName={
          access.school.name
        }
      />
    </>
  );
}
