import Link from "next/link";

import { LoginForm } from "./login-form";

interface LoginPageProps {
  searchParams: Promise<{
    school?: string;
  }>;
}

export default async function LoginPage({
  searchParams,
}: LoginPageProps) {
  const params =
    await searchParams;

  return (
    <main className="casa-shell">
      <div className="casa-container grid min-h-screen border-x border-black lg:grid-cols-[1.15fr_0.85fr]">
        <section className="flex min-h-[44vh] flex-col justify-between border-b border-black p-6 sm:p-10 lg:min-h-screen lg:border-b-0 lg:border-r lg:p-12">
          <div className="flex items-start justify-between gap-5">
            <Link
              className="casa-kicker hover:underline"
              href="/"
            >
              CASA / School
            </Link>
            <span className="casa-status">
              Secure access
            </span>
          </div>

          <div className="py-14 lg:py-20">
            <p className="casa-kicker casa-muted">
              School administration
            </p>
            <h1 className="casa-display mt-5 max-w-4xl">
              Enter the school
              <br />
              operating system.
            </h1>
          </div>

          <p className="max-w-xl text-sm leading-6 text-black/60">
            Registry, guardians, enrollment, identity cards and verified
            attendance share one source of truth. Sensitive actions can require
            an additional Passkey authorization.
          </p>
        </section>

        <section className="flex items-center p-6 sm:p-10 lg:p-12">
          <div className="w-full">
            <p className="casa-kicker">
              Sign in
            </p>
            <h2 className="casa-display-compact mt-4">
              School workspace.
            </h2>
            <p className="mt-4 max-w-md text-sm leading-6 text-black/55">
              Use the workspace slug supplied for your school and your CASA
              account credentials.
            </p>

            <div className="mt-9 border-t border-black pt-7">
              <LoginForm
                initialSchoolSlug={
                  params.school ?? ""
                }
              />
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
