"use client";

import {
  type FormEvent,
  useState,
} from "react";
import {
  browserSupportsWebAuthn,
  startAuthentication,
  type PublicKeyCredentialRequestOptionsJSON,
} from "@simplewebauthn/browser";
import { useRouter } from "next/navigation";

interface LoginFormProps {
  initialSchoolSlug: string;
}

type LoginMethod =
  | "PASSWORD"
  | "PASSKEY";

type JsonBody = {
  message?: string;
  authenticated?: boolean;
  ceremonyId?: string;
  options?: unknown;
  mustChangePassword?: boolean;
  roles?: string[];
};

export function LoginForm({
  initialSchoolSlug,
}: LoginFormProps) {
  const router =
    useRouter();

  const [
    method,
    setMethod,
  ] =
    useState<LoginMethod>(
      "PASSWORD",
    );

  const [
    schoolSlug,
    setSchoolSlug,
  ] =
    useState(
      initialSchoolSlug,
    );

  const [
    identifier,
    setIdentifier,
  ] =
    useState("");

  const [
    password,
    setPassword,
  ] =
    useState("");

  const [
    error,
    setError,
  ] =
    useState<string | null>(
      null,
    );

  const [
    busy,
    setBusy,
  ] =
    useState(false);

  function normalizedSchoolSlug() {
    return schoolSlug
      .trim()
      .toLowerCase();
  }

  async function routeAfterAuthentication(
    normalizedSlug: string,
  ) {
    const passwordStatusResponse =
      await fetch(
        "/api/auth/password/status",
        {
          cache:
            "no-store",
        },
      );

    const passwordStatus =
      (await passwordStatusResponse
        .json()
        .catch(
          () =>
            ({}),
        )) as JsonBody;

    if (
      passwordStatusResponse.ok &&
      passwordStatus
        .mustChangePassword
    ) {
      router.push(
        `/security/password?school=${encodeURIComponent(
          normalizedSlug,
        )}`,
      );
      router.refresh();
      return;
    }

    const accessResponse =
      await fetch(
        `/api/schools/${encodeURIComponent(
          normalizedSlug,
        )}/access`,
        {
          cache:
            "no-store",
        },
      );

    const access =
      (await accessResponse
        .json()
        .catch(
          () =>
            ({}),
        )) as JsonBody;

    if (
      !accessResponse.ok ||
      !Array.isArray(
        access.roles,
      )
    ) {
      throw new Error(
        access.message ??
          "Your account does not have access to this school workspace.",
      );
    }

    const roles =
      access.roles;

    if (
      roles.includes(
        "OWNER",
      ) ||
      roles.includes(
        "ADMIN",
      )
    ) {
      router.push(
        `/schools/${encodeURIComponent(
          normalizedSlug,
        )}/registry`,
      );
    } else if (
      roles.includes(
        "SCHOOL_TECHNICIAN",
      )
    ) {
      router.push(
        `/schools/${encodeURIComponent(
          normalizedSlug,
        )}/technician`,
      );
    } else if (
      roles.includes(
        "STAFF",
      )
    ) {
      router.push(
        `/schools/${encodeURIComponent(
          normalizedSlug,
        )}/my-class`,
      );
    } else {
      throw new Error(
        "This account does not currently have a CASA School staff workspace.",
      );
    }

    router.refresh();
  }

  async function submitPassword(
    event:
      FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

    setError(
      null,
    );
    setBusy(
      true,
    );

    try {
      const normalizedSlug =
        normalizedSchoolSlug();

      if (!normalizedSlug) {
        throw new Error(
          "Enter your school workspace slug.",
        );
      }

      if (
        !identifier.trim() ||
        !password
      ) {
        throw new Error(
          "Enter your email or phone and password.",
        );
      }

      const response =
        await fetch(
          "/api/auth/login",
          {
            method:
              "POST",
            headers: {
              "Content-Type":
                "application/json",
            },
            body:
              JSON.stringify({
                identifier,
                password,
              }),
          },
        );

      const body =
        (await response
          .json()
          .catch(
            () =>
              ({}),
          )) as JsonBody;

      if (!response.ok) {
        throw new Error(
          body.message ??
            "Unable to sign in.",
        );
      }

      await routeAfterAuthentication(
        normalizedSlug,
      );
    } catch (error) {
      setError(
        error instanceof Error
          ? error.message
          : "Unable to reach CASA School.",
      );
    } finally {
      setBusy(
        false,
      );
    }
  }

  async function submitPasskey() {
    setError(
      null,
    );

    const normalizedSlug =
      normalizedSchoolSlug();

    if (!normalizedSlug) {
      setError(
        "Enter your school workspace slug.",
      );
      return;
    }

    if (
      !browserSupportsWebAuthn()
    ) {
      setError(
        "This browser does not support secure Passkey sign-in.",
      );
      return;
    }

    setBusy(
      true,
    );

    try {
      const optionsResponse =
        await fetch(
          "/api/auth/passkeys/login/options",
          {
            method:
              "POST",
          },
        );

      const optionsBody =
        (await optionsResponse
          .json()
          .catch(
            () =>
              ({}),
          )) as JsonBody;

      if (
        !optionsResponse.ok ||
        typeof optionsBody
          .ceremonyId !==
          "string" ||
        !optionsBody.options
      ) {
        throw new Error(
          optionsBody.message ??
            "Unable to start Passkey sign-in.",
        );
      }

      const authenticationResponse =
        await startAuthentication({
          optionsJSON:
            optionsBody.options as
              PublicKeyCredentialRequestOptionsJSON,
        });

      const verifyResponse =
        await fetch(
          "/api/auth/passkeys/login/verify",
          {
            method:
              "POST",
            headers: {
              "Content-Type":
                "application/json",
            },
            body:
              JSON.stringify({
                ceremonyId:
                  optionsBody
                    .ceremonyId,
                response:
                  authenticationResponse,
              }),
          },
        );

      const verifyBody =
        (await verifyResponse
          .json()
          .catch(
            () =>
              ({}),
          )) as JsonBody;

      if (
        !verifyResponse.ok ||
        !verifyBody
          .authenticated
      ) {
        throw new Error(
          verifyBody.message ??
            "Passkey sign-in failed.",
        );
      }

      await routeAfterAuthentication(
        normalizedSlug,
      );
    } catch (error) {
      setError(
        error instanceof Error
          ? error.message
          : "Unable to sign in with your Passkey.",
      );
    } finally {
      setBusy(
        false,
      );
    }
  }

  return (
    <div
      className="grid gap-5"
    >
      <label className="casa-label">
        <span>
          School workspace
        </span>
        <input
          required
          value={
            schoolSlug
          }
          onChange={(
            event,
          ) =>
            setSchoolSlug(
              event
                .target
                .value,
            )
          }
          placeholder="school-slug"
          autoComplete="organization"
          className="casa-field"
        />
      </label>

      <div
        className="grid grid-cols-2 border-y border-black"
        role="tablist"
        aria-label="Sign-in method"
      >
        <button
          type="button"
          role="tab"
          aria-selected={
            method ===
            "PASSWORD"
          }
          className={`min-h-12 border-r border-black px-3 text-left font-mono text-[10px] font-semibold uppercase tracking-[0.12em] ${
            method ===
            "PASSWORD"
              ? "bg-black text-white"
              : "bg-transparent text-black/55"
          }`}
          onClick={() => {
            setMethod(
              "PASSWORD",
            );
            setError(
              null,
            );
          }}
        >
          Password
        </button>

        <button
          type="button"
          role="tab"
          aria-selected={
            method ===
            "PASSKEY"
          }
          className={`min-h-12 px-3 text-left font-mono text-[10px] font-semibold uppercase tracking-[0.12em] ${
            method ===
            "PASSKEY"
              ? "bg-black text-white"
              : "bg-transparent text-black/55"
          }`}
          onClick={() => {
            setMethod(
              "PASSKEY",
            );
            setError(
              null,
            );
          }}
        >
          Passkey
        </button>
      </div>

      {method ===
      "PASSWORD" ? (
        <form
          className="grid gap-5"
          onSubmit={
            submitPassword
          }
        >
          <label className="casa-label">
            <span>
              Email or phone
            </span>
            <input
              required
              value={
                identifier
              }
              onChange={(
                event,
              ) =>
                setIdentifier(
                  event
                    .target
                    .value,
                )
              }
              autoComplete="username"
              className="casa-field"
            />
          </label>

          <label className="casa-label">
            <span>
              Password
            </span>
            <input
              required
              type="password"
              value={
                password
              }
              onChange={(
                event,
              ) =>
                setPassword(
                  event
                    .target
                    .value,
                )
              }
              autoComplete="current-password"
              className="casa-field"
            />
          </label>

          <button
            disabled={
              busy
            }
            className="casa-button w-full"
            type="submit"
          >
            {busy
              ? "Signing in..."
              : "Sign in →"}
          </button>
        </form>
      ) : (
        <div>
          <p className="text-sm leading-6 text-black/55">
            Use the Passkey registered to your own CASA identity.
            Shared devices are supported, but staff accounts must never be shared.
          </p>

          <button
            disabled={
              busy
            }
            className="casa-button mt-5 w-full"
            type="button"
            onClick={() =>
              void submitPasskey()
            }
          >
            {busy
              ? "Verifying..."
              : "Continue with Passkey →"}
          </button>
        </div>
      )}

      {error ? (
        <div
          className="casa-error"
          role="alert"
        >
          {error}
        </div>
      ) : null}

      <p className="text-xs leading-5 text-black/40">
        CASA routes Admins, Teachers and School Technicians to their own authorized workspace after sign-in.
      </p>
    </div>
  );
}
