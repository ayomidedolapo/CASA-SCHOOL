import Link from "next/link";

export default function Home() {
  return (
    <main className="casa-shell">
      <section className="casa-container grid min-h-screen border-x border-black lg:grid-cols-[1.25fr_0.75fr]">
        <div className="flex min-h-[58vh] flex-col justify-between border-b border-black p-6 sm:p-10 lg:min-h-screen lg:border-b-0 lg:border-r lg:p-12">
          <div className="flex items-start justify-between gap-6">
            <p className="casa-kicker">
              CASA / School
            </p>
            <span className="casa-status casa-status-positive">
              Operations
            </span>
          </div>

          <div className="py-16 lg:py-24">
            <p className="casa-kicker casa-muted">
              Identity · Registry · Attendance
            </p>
            <h1 className="casa-display mt-5 max-w-5xl">
              One school.
              <br />
              One source of truth.
            </h1>
          </div>

          <p className="max-w-2xl text-sm leading-6 text-black/60">
            CASA School connects student identity, guardians, enrollment,
            secure school-issued cards and verified attendance in one
            operational system.
          </p>
        </div>

        <div className="flex flex-col justify-between p-6 sm:p-10 lg:p-12">
          <div>
            <p className="casa-kicker">
              Start
            </p>
            <h2 className="casa-display-compact mt-5">
              Enter the workspace you need.
            </h2>
          </div>

          <div className="mt-14 border-t border-black">
            <Link
              className="group grid grid-cols-[1fr_auto] gap-6 border-b border-black py-5 text-left"
              href="/login"
            >
              <span>
                <strong className="block text-lg">
                  School workspace
                </strong>
                <span className="mt-1 block text-sm text-black/55">
                  Registry, identity and attendance administration.
                </span>
              </span>
              <span className="font-mono text-sm transition-transform group-hover:translate-x-1">
                →
              </span>
            </Link>

            <Link
              className="group grid grid-cols-[1fr_auto] gap-6 border-b border-black py-5 text-left"
              href="/scanner"
            >
              <span>
                <strong className="block text-lg">
                  Scanner terminal
                </strong>
                <span className="mt-1 block text-sm text-black/55">
                  Device-bound card, face and attendance verification.
                </span>
              </span>
              <span className="font-mono text-sm transition-transform group-hover:translate-x-1">
                →
              </span>
            </Link>

            <Link
              className="group grid grid-cols-[1fr_auto] gap-6 border-b border-black py-5 text-left"
              href="/security/passkeys"
            >
              <span>
                <strong className="block text-lg">
                  Account security
                </strong>
                <span className="mt-1 block text-sm text-black/55">
                  Register and review Passkeys for sensitive operations.
                </span>
              </span>
              <span className="font-mono text-sm transition-transform group-hover:translate-x-1">
                →
              </span>
            </Link>
          </div>

          <p className="mt-12 font-mono text-[10px] uppercase tracking-[0.16em] text-black/45">
            Secure school operations / CASA
          </p>
        </div>
      </section>
    </main>
  );
}
